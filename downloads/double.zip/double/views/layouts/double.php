<?php $this->beginContent('//layouts/main'); ?>
<div class="container">
	<div id="content" class="span-11">
		<?php echo $content; ?>
	</div><!-- content -->
	<div class="span-11">
		<p>
			<h2>Sidebar</h2>
			Sidebar content here
		</p>

	</div>
</div>
<?php $this->endContent(); ?>
