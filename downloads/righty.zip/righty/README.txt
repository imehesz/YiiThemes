just update the components/Controller.php
public $layout="//layouts/righty"
