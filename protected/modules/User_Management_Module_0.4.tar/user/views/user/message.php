<?php $this->pageTitle=Yii::app()->name . ' - '.Yii::t("UserModule.user", "Login"); ?>

<h1><?php echo $title; ?></h1>

<div class="form">
<?php echo $content; ?>

</div><!-- yiiForm -->
